/*
    This file describes the Room class
*/ 

#ifndef ROOM_H
#define ROOM_H

#include <iostream>
#include "event.h"

class Room {
    public:
        Event* ev = nullptr;    
};

#endif