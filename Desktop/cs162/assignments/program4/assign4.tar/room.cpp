#include <iostream>
#include "room.h"

using namespace std;

/* This class do be empty T-T */