#include <iostream>
#include "event.h"

using namespace std;

/* This class do be empty T-T */