/*
    This file describes generic functions
*/ 

#ifndef CRAZYEIGHTS_H
#define CRAZYEIGHTS_H

#include <iostream>
#include <string>

using namespace std;

void nameCard (int, string &, string &);

#endif